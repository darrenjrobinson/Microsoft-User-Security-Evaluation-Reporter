﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2017 v5.4.135
	 Created on:   	2/8/2017 10:26 AM
     Edited on::    4/22/2017
	 Created by:   	Mark Kraus
	 Organization: 	
	 Filename:     	Get-GraphOauthAccessTokenCC.ps1
	===========================================================================
	.DESCRIPTION
		Get-GraphOauthAccessTokenCC Function
#>

<#
    .SYNOPSIS
        Retieves an OAuth Access Token from Microsoft
    
    .DESCRIPTION
        Takes an OAuth Access Authorization code returned from Get-GraphOauthAuthorizationCode and
        requests an OAuth Access Token for the provided resource from Microsoft. A
        MSGraphAPI.Oauth.AccessToken object is returned. This object is required for making calls
        to Invoke-GraphRequest and many other functions provided by this module.
    
    .PARAMETER BaseURL
        The Base URL used for retrieving OAuth Access Tokens. This is not required. the default is
        
        https://login.microsoftonline.com/common/oauth2/token
    
    .PARAMETER ClientID
        ClientID from the Application registered in Azure AD

    .PARAMETER GraphApp
        GraphApp from the New-GraphApplication cmdlet

    .PARAMETER ClientSecret
        ClientSecret from the Application registered in Azure AD

    .PARAMETER Username
        Username as UPN from AAD 

    .PARAMETER UserPassword
        Clear Text Password for the Username as UPN from AAD 

    .PARAMETER Redirect URL
        AAD Registered App Redirect URL e.g https://localhost

    .PARAMETER Tenant Name
        AAD Tenant Name e.g mycompany.onmicrosoft.com

    .PARAMETER Resource
        The resource for which the OAuth Access token will be requested. The default is
        
            https://graph.microsoft.com
    
        You must set the resource to match the endpoints your token will be valid for.

            Microsft Graph:              https://graph.microsoft.com
            Azure AD Graph API:          https://graph.windows.net
            Office 365 Unified Mail API: https://outlook.office.com
        
        If you need to access more than one resrouce, you will need to request multiple OAuth Access 
        Tokens and use the correct tokens for the correct endpoints.

    .EXAMPLE
        PS C:\> $ClientCredential = Get-Credential
        PS C:\> $Params = @{
        Name = 'MyGraphApp'
        Description = 'My Graph Application!'
        ClientCredential = $ClientCredential
        RedirectUri = 'https://adataum/ouath?'
        UserAgent = 'Windows:PowerShell:GraphApplication'
        }
        PS C:\> $GraphApp = New-GraphApplication @Params        
        PS C:\> $GraphAccessToken = Get-GraphOauthAccessTokenCC -GraphApp -ClientID $clientID -ClientSecret $clientSecret -Username $userUPN -Password $strPassword
    
    .OUTPUTS
        MSGraphAPI.Oauth.AccessToken
    
    .NOTES        
        See Export-GraphOauthAccessToken for exporting Graph Acess Token Objects
        See Import-GraphOauthAccessToken for importing exported Graph AcessToken Objects
        See Update-GraphOauthAccessToken for refreshing the Graph Access Token
    
    .LINK
        http://psmsgraph.readthedocs.io/en/latest/functions/Get-GraphOauthAccessToken
    .LINK
        http://psmsgraph.readthedocs.io/en/latest/functions/Get-GraphOauthAuthorizationCode
    .LINK
        http://psmsgraph.readthedocs.io/en/latest/functions/Export-GraphOauthAccessToken
    .LINK
        http://psmsgraph.readthedocs.io/en/latest/functions/Import-GraphOauthAccessToken
    .LINK
        http://psmsgraph.readthedocs.io/en/latest/functions/Update-GraphOauthAccessToken
    .LINK
        https://graph.microsoft.io/en-us/docs/authorization/auth_overview
#>
function Get-GraphOauthAccessTokenCC {
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute("PSAvoidUsingConvertToSecureStringWithPlainText","")]
    [CmdletBinding(ConfirmImpact = 'Low',
                   HelpUri = 'http://psmsgraph.readthedocs.io/en/latest/functions/Get-GraphOauthAccessToken',
                   SupportsShouldProcess = $true)]
    [OutputType('MSGraphAPI.Oauth.AccessToken')]
    param
    (        
        
        [Parameter(Mandatory=$true, 
                    ValueFromPipelineByPropertyName = $true)]
        [string]$ClientID, 
        
        [Parameter(Mandatory = $true,
                   ValueFromPipelineByPropertyName = $true)]
        [string]$ClientSecret,
       
        [Parameter(Mandatory = $true,
                   ValueFromPipelineByPropertyName = $true)]
        [string]$Username,
       
        [Parameter(Mandatory = $true,
                   ValueFromPipelineByPropertyName = $true)]
        [string]$UserPassword,

        [Parameter(Mandatory = $true,
                   ValueFromPipelineByPropertyName = $true)]
        [string]$TenantName,       

        [Parameter(Mandatory = $true,
                   ValueFromPipelineByPropertyName = $true)]
        [string]$RedirectURI,       

        [Parameter(Mandatory = $false,
                   ValueFromPipelineByPropertyName = $true)]
        [Alias('URL')]
        [string]$BaseURL = "https://login.microsoftonline.com/qantas.onmicrosoft.com/oauth2/v2.0/token",        
        
        [Parameter(Mandatory = $false,
                   ValueFromPipelineByPropertyName = $true)]
        [string]$Resource = 'https://graph.microsoft.com'
    )
    
    Process {
        

        $Client_Id = [System.Web.HttpUtility]::UrlEncode($ClientID)
        $Client_Secret = [System.Web.HttpUtility]::UrlEncode($ClientSecret)

        $Redirect_uri = [System.Web.HttpUtility]::UrlEncode($RedirectURI)
        $Resource_encoded = [System.Web.HttpUtility]::UrlEncode($Resource)
        
        $Body = @(
            'grant_type=client_credentials'
            '&redirect_uri={0}' -f $Redirect_uri
            '&client_id={0}' -f $Client_Id
            '&client_secret={0}' -f $Client_Secret
            '&scope=https%3A%2F%2Fgraph.microsoft.com%2F.default'
        ) -join ''
        Write-Verbose "Body: $Body"
        $RequestedDate = Get-Date
        $Params = @{
            Uri = $BaseURL
            Method = 'POST'
            ContentType = "application/x-www-form-urlencoded"
            Body = $Body
            ErrorAction = 'Stop'
            SessionVariable = 'Session'
        }
        try {
            Write-Verbose "Retrieving OAuth Access Token from $BaseURL..."
            $Result = Invoke-WebRequest @Params
        }
        catch {
            $_.Exception.
                psobject.
                TypeNames.
                Insert(0,'MSGraphAPI.Oauth.Exception')
            Write-Error -Exception $_.Exception
            return
        }
        try {
            $Content = $Result.Content | ConvertFrom-Json -ErrorAction Stop
            write-Verbose $Result
        }
        Catch {
            $Params = @{
                MemberType = 'NoteProperty'
                Name = 'Respone' 
                Value = $Result
            }
            $_.Exception | Add-Member @Params
            Write-Error -Exception $_.Exception
            return
        }
        $SecureAccessToken = $Content.access_token | ConvertTo-SecureString -AsPlainText -Force
        Write-Verbose "SecureAccessToken: $($SecureAccessToken)"
        write-Verbose $Content
        $SecureRefreshToken = $Content.access_token | ConvertTo-SecureString -AsPlainText -Force
        Write-Verbose "SecureRefreshToken: $($SecureAccessToken)"
        $AccessTokenCredential = [pscredential]::new('access_token', $SecureAccessToken )
        $RefreshTokenCredential = [pscredential]::new('refresh_token', $SecureRefreshToken)
         
        $Params = @{            
            Application = $Application
            AccessTokenCredential = $AccessTokenCredential
            RefreshTokenCredential = $RefreshTokenCredential
            RequestedDate = $RequestedDate
            Response = $Content | Select-Object -property * -ExcludeProperty access_token, refresh_token
            ResponseHeaders = $Result.Headers
            LastRequestDate = $RequestedDate
            Session = $Session
            GUID = [guid]::NewGuid()
        }
        New-GraphOauthAccessToken @Params
    }
}
