# POST method: $req
$requestBody = Get-Content $req -Raw | ConvertFrom-Json
$requestBody = $requestBody | convertFrom-json
$uri = 'https://graph.microsoft.com/beta/$batch'

write-output "full request: $($requestBody)"

# Get the Request batch body 
$batchBody = $requestBody.bodyRequests
$jsonbody = $requestBody.bodyRequests | convertTo-json

$token = $requestBody.token
$method = $requestBody.method 
$userUPN = $requestBody.userUPN

write-output "URI: $($uri)"
write-output "method: $($method)"
write-output "userUPN: $($userUPN)"
write-output "token: $($token)"

# Fix encoding of single quotes
$batchBody = $jsonbody | ConvertFrom-Json | ConvertTo-Json | ForEach-Object{
    [Regex]::Replace($_, 
        "\\u(?<Value>[a-zA-Z0-9]{4})", {
            param($m) ([char]([int]::Parse($m.Groups['Value'].Value,
                [System.Globalization.NumberStyles]::HexNumber))).ToString() } )}

write-output "body: $($batchBody)"

# Enable Basic Parsing otherwise webrequests fail
& $(get-module PSMSGraph) {$PSDefaultParameterValues['Invoke-WebRequest:UseBasicParsing']=$true}

$tokensPath = 'D:\home\site\wwwroot\MSUser\token\'

if (test-path -Path $tokensPath) {   
    # Managed Service Identity EndPoint 
    $endpoint = $env:MSI_ENDPOINT
    $secret = $env:MSI_SECRET
    $vaultTokenURI = 'https://vault.azure.net&api-version=2017-09-01'

    # Vault URI's for Access and Refresh Tokens
    # NOTE: API Version for these calls is 2016-10-01
    $vaultSecretAccessTokenURI = 'https://yourVaultName.vault.azure.net/secrets/AccessToken?'
    $vaultSecretRefreshTokenURI = 'https://yourVaultName.vault.azure.net/secrets/RefreshToken?'

    # Create AuthN Header with our Function App Secret
    $header = @{'Secret' = $secret}

    # Get Key Vault Access Token
    $authenticationResult = Invoke-RestMethod -Method Get -Headers $header -Uri ($endpoint +'?resource=' +$vaultTokenURI)
    # Use Key Vault Access Token to create Request Header
    $requestHeader = @{ Authorization = "Bearer $($authenticationResult.access_token)" }

    # Call the Vault and Retrieve Creds
    # Refresh Token
    $rt = Invoke-RestMethod -Method GET -Uri "$($vaultSecretRefreshTokenURI)api-version=2016-10-01" -ContentType 'application/json' -Headers $requestHeader
    $refreshToken = $rt.value
    write-output "===Refresh Token==="
    write-output $refreshToken
    write-output "************************"

    # Access Token
    $at = Invoke-RestMethod -Method GET -Uri "$($vaultSecretAccessTokenURI)api-version=2016-10-01" -ContentType 'application/json' -Headers $requestHeader
    $accessToken = $at.value
    write-output "===Access Token==="
    write-output $accessToken
    write-output "************************"

    # Token artifacts
    $tokenReponseFile = 'myTokenResponse.json'
    $response = get-content -path "$($tokensPath)$($tokenReponseFile)" | ConvertFrom-Json

    $tokenReponseHeadersFile = 'myTokenResponseHeaders.json'
    $responseHeaders = get-content -path "$($tokensPath)$($tokenReponseHeadersFile)" | ConvertFrom-Json

    $graphAppFile = 'myGraphApp.json'
    $graphApp = get-content -path "$($tokensPath)$($graphAppFile)" | ConvertFrom-Json
    
    $graphAppCredPwd = ConvertTo-SecureString "yourAppSecret" -AsPlainText -Force
    $graphAppCreds = New-Object System.Management.Automation.PSCredential ("yourAppID", $graphAppCredPwd)

    $GraphApplication = [pscustomobject]@{PSTypeName = 'MSGraphAPI.Application' 
        Name = $graphApp.Name
        Description = $graphApp.Description 
        ClientCredential = $graphAppCreds 
        RedirectUri = $graphApp.RedirectUri
        Tenant = $graphApp.Tenant  
        GUID = $graphApp.GUID            
        }

    $tokenRequestDateFile = 'myTokenRequestDate.txt'
    $tokenRequestDate = get-content -path "$($tokensPath)$($tokenRequestDateFile)" 
    $tokenRDate = get-date($tokenRequestDate)

    $tokenLastRequestDateFile = 'myTokenLastRequestDate.txt'
    $tokenLastRequestDate = get-content -path "$($tokensPath)$($tokenLastRequestDateFile)" 
    $tokenLRDate = get-date($tokenLastRequestDate)
    
    # GET NEW TOKENS & Export for next run

    if ($response -and $responseHeaders -and $GraphApplication -and $tokenRDate -and $tokenLRDate -and $refreshToken -and $accessToken) {

        $graphAppAccessToken = ConvertTo-SecureString $accessToken -AsPlainText -Force
        $graphAppAccessTokenCreds = New-Object System.Management.Automation.PSCredential ("graphAppAT", $graphAppAccessToken)

        $graphAppRefreshToken = ConvertTo-SecureString $refreshToken -AsPlainText -Force
        $graphAppRefreshTokenCreds = New-Object System.Management.Automation.PSCredential ("graphAppRT", $graphAppRefreshToken)
                                
        $GraphAccessToken = New-GraphOauthAccessToken -AccessTokenCredential $graphAppAccessTokenCreds -RefreshTokenCredential $graphAppRefreshTokenCreds -RequestedDate $tokenRDate -LastRequestDate $tokenLRDate -Application $graphApplication -Response $response -ResponseHeaders $responseHeaders            
        
        if ($GraphAccessToken) {
            # Check to see if Token has expired. Refresh if it has and is Refreshable.
            if (($GraphAccessToken.IsExpired.Equals($True) -and $GraphAccessToken.IsRefreshable.Equals($True) ))  {
                write-output "Token has expired but is refreshable. Refreshing Tokens."
                Update-GraphOauthAccessToken -AccessToken $GraphAccessToken -Force 
                $tokenDebugFile = 'tokendebug.json'
                $GraphAccessToken | convertto-json | out-file "$($tokensPath)$($tokenDebugFile)"            
            }

            $timeNow = Get-date 
            if ($timeNow.AddMinutes(10) -gt $GraphAccessToken.Expires) {
                # Refresh token as it may expire before this execution completes
                write-output "Token will expire at $($GraphAccessToken.Expires) so refreshing so it doesn't expire before Function completes."
                Update-GraphOauthAccessToken -AccessToken $GraphAccessToken -Force 
                $tokenDebugFile = 'tokendebug.json'
                $GraphAccessToken | convertto-json | out-file "$($tokensPath)$($tokenDebugFile)" 
                write-output "Tokens refreshed and will now expire at $($GraphAccessToken.Expires)."           
            }
        }
        
        # Output info for next run if new token is valid
        if ($GraphAccessToken) {
            if (($GraphAccessToken.IsExpired.Equals($False) -and $GraphAccessToken.IsRefreshable.Equals($True) ))  {
                $newGraphAccessToken = $GraphAccessToken
                
                write-output "Tokens are valid. Exporting token info for next execution"
                
                $tokenResponse = $GraphAccessToken.Response | Select-Object -property * -ExcludeProperty access_token, refresh_token
                $tokenResponse | convertto-json | out-file "$($tokensPath)$($tokenReponseFile)"                                
                
                $GraphAccessToken.ResponseHeaders | convertto-json | out-file "$($tokensPath)$($tokenReponseHeadersFile)" 
                
                $GraphAccessToken.RequestedDate.DateTime | out-file "$($tokensPath)$($tokenRequestDateFile)"

                $GraphAccessToken.LastRequestDate.DateTime | out-file "$($tokensPath)$($tokenLastRequestDateFile)"

                # Update Access and Refresh Toekns in the Vault
                # New Token Values
                $bodyAT = @{value = $GraphAccessToken.GetAccessToken()} | convertTo-Json
                $bodyRT = @{value = $GraphAccessToken.GetRefreshToken()} | convertTo-Json

                # Update Vault with new tokens
                # NOTE: API Ver for this is 7.0
                write-output "AccessToken $($vaultSecretAccessTokenURI)api-version=7.0"
                $newAT = Invoke-RestMethod -Method Put -Uri "$($vaultSecretAccessTokenURI)api-version=7.0" -ContentType 'application/json' -Headers $requestHeader -body $bodyAT
                write-output "-------------------"
                write-output $newAT

                write-output "RefreshToken $($vaultSecretRefreshTokenURI)api-version=7.0"
                $newRT = Invoke-RestMethod -Method Put -Uri "$($vaultSecretRefreshTokenURI)api-version=7.0" -ContentType 'application/json' -Headers $requestHeader -body $bodyRT
                write-output "+++++++++++++++++++"
                write-output $newRT

            } else {
                write-output "oAuth Token is Expired or cannot be Refreshed. Update externally and upload to Az Function"
                $output = "oAuth Token is Expired or cannot be Refreshed. Update externally and upload to Az Function"
            }
        } else {
            write-output "New oAuth Token attempt failed. Token not valid"
            $output = "oAuth Token is Expired or cannot be Refreshed. Update externally and upload to Az Function"
        }   
            
    } else {
        write-output "Some oAuth Refresh information not found"
        $output = "Some oAuth Refresh information not found"            
    }

} else {
    write-output "oAuth Refresh information not found"
    $output = "oAuth Refresh information not found" 
}

# Checkout the Request and execute it
if ($uri -and $method) {
    if ($GraphAccessToken.IsExpired.Equals($False)) {
        if ($batchBody){                        
            try{
                $requestResult = Invoke-GraphRequest -AccessToken $newGraphAccessToken -Uri $uri -Method $method -body $batchBody
                write-output "Sending Request. URI : $($uri) Method: $($method) Body: $($batchBody)"
                write-output ($requestResult.Result.Content | convertfrom-json).responses
               
                $output = ($requestResult.Result.Content | convertfrom-json).responses
                if ($requestResult.Result.Content){                   
                
                    foreach ($jobResult in ($requestResult.Result.Content | convertfrom-json).responses) {
                        write-output "jobID: $($jobResult.id)"
                        
                        switch ($jobResult.id){
                            1 {# SSPR Events
                                $userPWDEvents = $null 
                                $userPwdEvents = $jobResult.body.value | select-object | Where-Object { $_.initiatedBy.user.userPrincipalName -eq $userUPN}        
                                if ($userPwdEvents.count -gt 0){

                                    $userPwdEventsCount = $userPwdEvents.count

                                    # Password Reset Events Table Header Row
                                    $userPWDResetsTableHeader = '<h2>Password Reset events for the last 30 days</h2><table class="table table-sm" id="returnedSSPREvents"> 
                                    <thead>
                                        <tr>
                                            <th>Date Time</th>            
                                            <th>Password Reset Activity</th>
                                            <th>Reset Result</th>
                                            <th>Result Reason</th>
                                            <th>ipAddress</th>
                                            </tr>'   

                                            $userPWDResetsTableBody = @()

                                    foreach ($pwdEvent in $userPwdEvents) {
                                        if ($pwdEvent.id) {
                                            $userPWDResetsTableContent = "<tr>
                                            <td>pwdEventDateTime</td>
                                            <td>pwdEventActivity</td>
                                            <td>pwdEventResult</td>
                                            <td>pwdEventReason</td>
                                            <td>pwdEventIpAddress</td>
                                            </tr>"
                                            
                                            $dateTimeAdjusted = $null 
                                            $dateTimeAdjusted = get-date($($pwdEvent.activityDateTime))
                                            $dateTimeAdjusted = $dateTimeAdjusted.AddHours(11)
                                            $userPWDResetsTableContent = $userPWDResetsTableContent.Replace("pwdEventDateTime", $($dateTimeAdjusted))
                                            $userPWDResetsTableContent = $userPWDResetsTableContent.Replace("pwdEventIpAddress", $($pwdEvent.initiatedBy.user.ipAddress))            
                                            $userPWDResetsTableContent = $userPWDResetsTableContent.Replace("pwdEventActivity", $($pwdEvent.activityDisplayName))
                                            $userPWDResetsTableContent = $userPWDResetsTableContent.Replace("pwdEventResult", $($pwdEvent.result))
                                            $userPWDResetsTableContent = $userPWDResetsTableContent.Replace("pwdEventReason", $($pwdEvent.resultReason))
                                
                                            $userPWDResetsTableBody += $userPWDResetsTableContent                            
                                        }
                                    }

                                    # Password Reset Events Results End
                                    $userPWDResetsTableHeaderEnd = '</thead></table>'

                                    $userPWDEventsTableDisplay = $userPWDResetsTableHeader + $userPWDResetsTableBody + $userPWDResetsTableHeaderEnd
                                    $output1 = $userPWDEventsTableDisplay

                                } else {
                                    $userPwdEventsCount = 0
                                    $output1 = '<h2 id="returnedSSPREvents">Password Reset events for the last 30 days</h2><p>No password reset events found.</p>'
                                }
                            }
                            2 {# Sign-Ins
                                $userSignInEvents = $null 
                                $userSignInEvents = $jobResult.body.value         
                                if ($userSignInEvents.count -gt 0){

                                    $userSignInEventsCount = $userSignInEvents.count
                                    # SignIn Events Table Header Row
                                    $signInEventsTableHeader = '<h2>Last 10 sign-in events in the last 30 days</h2><table class="table table-sm" id="signInEventsTable"> 
                                    <thead>
                                        <tr>
                                            <th>Date Time</th>            
                                            <th>Display Name</th>
                                            <th>ipAddress</th>
                                            <th>Conditional Access Status</th>
                                            <th>MFA Auth Method</th>
                                            <th>MFA Auth Detail</th>
                                            <th>Device DisplayName</th>
                                            <th>Device OS</th>
                                            <th>Device Browser</th>
                                            <th>Device isCompliant</th>
                                            <th>Device isManaged</th>
                                            <th>Device Trust Type</th>
                                            <th>Location City</th>
                                            <th>Location State</th>
                                            <th>Location Country</th>
                                            </tr>'   

                                    foreach ($SignIn in $userSignInEvents){
                                            if ($signIn.id) {    
                                                #Write-output "User: $($signIn.userdisplayName) UPN: $($signIn.UserPrincipalName) Event: $($signIn.ipAddress)"           
                                                
                                                $signInEventsTableContent = "<tr>
                                                <td>signInDateTime</td>            
                                                <td>signInDisplayName</td>
                                                <td>signInIpAddress</td>
                                                <td>signInConditional</td>
                                                <td>signInMFAAuthMethod</td>
                                                <td>signInMFAAuthDetail</td>
                                                <td>signInDeviceDisplayName</td>
                                                <td>signInDeviceOS</td>
                                                <td>signInDeviceBrowser</td>
                                                <td>signInDeviceisCompliant</td>
                                                <td>signInDeviceisManaged</td>
                                                <td>signInDeviceTrustType</td>
                                                <td>signInLocationCity</td>
                                                <td>signInLocationState</td>
                                                <td>signInLocationCountry</td>
                                                </tr>"
                                            
                                                $dateTimeAdjusted = $null 
                                                $dateTimeAdjusted = get-date($($signIn.createdDateTime))
                                                $dateTimeAdjusted = $dateTimeAdjusted.AddHours(11)
                                                $signInEventsTableContent = $signInEventsTableContent.Replace("signInDateTime", $($dateTimeAdjusted))
                                                $signInEventsTableContent = $signInEventsTableContent.Replace("signInDisplayName", $($signIn.userDisplayName))
                                                $signInEventsTableContent = $signInEventsTableContent.Replace("signInIpAddress", $($signIn.ipAddress))
                                                $signInEventsTableContent = $signInEventsTableContent.Replace("signInConditional", $($signIn.conditionalAccessStatus))
                                                $signInEventsTableContent = $signInEventsTableContent.Replace("signInMFAAuthMethod", $($signIn.mfaDetail.authMethod))
                                                $signInEventsTableContent = $signInEventsTableContent.Replace("signInMFAAuthDetail", $($signIn.mfaDetail.authDetail))
                                                $signInEventsTableContent = $signInEventsTableContent.Replace("signInDeviceDisplayName", $($signIn.deviceDetail.displayName))
                                                $signInEventsTableContent = $signInEventsTableContent.Replace("signInDeviceOS", $($signIn.deviceDetail.operatingSystem))
                                                $signInEventsTableContent = $signInEventsTableContent.Replace("signInDeviceBrowser", $($signIn.deviceDetail.browser))
                                                $signInEventsTableContent = $signInEventsTableContent.Replace("signInDeviceisCompliant", $($signIn.deviceDetail.isCompliant))
                                                $signInEventsTableContent = $signInEventsTableContent.Replace("signInDeviceisManaged", $($signIn.deviceDetail.isManaged))
                                                $signInEventsTableContent = $signInEventsTableContent.Replace("signInDeviceTrustType", $($signIn.deviceDetail.trustType))
                                                $signInEventsTableContent = $signInEventsTableContent.Replace("signInLocationCity", $($signIn.location.city))
                                                $signInEventsTableContent = $signInEventsTableContent.Replace("signInLocationState", $($signIn.location.state))
                                                $signInEventsTableContent = $signInEventsTableContent.Replace("signInLocationCountry", $($signIn.location.countryOrRegion))
                                                $userSignInTableBody += $signInEventsTableContent
                                    
                                            }    
                                            # SignIn Events Results End
                                            $signInEventsTableHeaderEnd = '</thead></table>'
                                    
                                            $userSignInEventsTableDisplay = $signInEventsTableHeader + $userSignInTableBody + $signInEventsTableHeaderEnd
                                            $output2 = $userSignInEventsTableDisplay                                                    
                                        }                                        
                                } else {
                                    $userSignInEventsCount = 0
                                    $output2 = '<h2 id="returnedSignInEvents">Sign-In events for the last 30 days</h2><p>No Sign-In events found.</p>'
                                }
                            }
                            3 {# Risk Events
                                $userRiskEvents = $null 
                                                                
                                # Order events on DateTime                                
                                $userRiskEvents = $jobResult.body.value | Sort-Object {$_.riskEventDateTime -as [datetime]} -Descending

                                if ($userRiskEvents.Count -gt 0) {
                                    $userRiskEventsCount = $userRiskEvents.Count
                                    # User Risk Results Table Header Row
                                    $userRiskEventsTableHeader = '<h2>Upto the last 10 user risk events</h2><table class="table table-sm" id="userRiskEventsTable"> 
                                    <thead>
                                        <tr>    
                                            <th>Date Time</th>            
                                            <th>Display Name</th>
                                            <th>Risk Status</th>
                                            <th>Risk Event</th>
                                            <th>Risk Level</th>
                                            <th>userPrincipalName (UPN)</th>
                                            <th>Location City</th>
                                            <th>Location Country</th>
                                            <th>ipAddress</th>
                                            </tr>'   

                                            $userRiskTableBody = @()

                                    foreach ($userRisk in $userRiskEvents) {
                                        if ($userRisk.id) {
                                            Write-output "User: $($userRisk.userDisplayName) UPN: $($userRisk.UserPrincipalName) Risk: $($userRisk.riskEventType)"           
                                                                    
                                            $userRiskEventsDetailsTableContent = "<tr>        
                                                <td>riskEventDateTime</td>
                                                <td>riskEventDisplayName</td>
                                                <td>riskEventStatus</td>
                                                <td>riskEventEvent</td>
                                                <td>riskEventLevel</td>
                                                <td>riskEventUPN</td>
                                                <td>riskEventLocCity</td>
                                                <td>riskEventLocCountry</td>
                                                <td>riskEventIpAddress</td>                
                                                </tr>"
                                                
                                            $dateTimeAdjusted = $null 
                                            $dateTimeAdjusted = get-date($($userRisk.riskEventDateTime))
                                            $dateTimeAdjusted = $dateTimeAdjusted.AddHours(11)
                                                
                                            $userRiskEventsDetailsTableContent = $userRiskEventsDetailsTableContent.Replace("riskEventDateTime", $($dateTimeAdjusted))
                                            $userRiskEventsDetailsTableContent = $userRiskEventsDetailsTableContent.Replace("riskEventDisplayName", $($userRisk.userDisplayName))
                                            $userRiskEventsDetailsTableContent = $userRiskEventsDetailsTableContent.Replace("riskEventStatus", $($userRisk.riskEventStatus))
                                            $userRiskEventsDetailsTableContent = $userRiskEventsDetailsTableContent.Replace("riskEventEvent", $($userRisk.riskEventType))
                                            $userRiskEventsDetailsTableContent = $userRiskEventsDetailsTableContent.Replace("riskEventLevel", $($userRisk.riskLevel))
                                            $userRiskEventsDetailsTableContent = $userRiskEventsDetailsTableContent.Replace("riskEventUPN", $($userRisk.userPrincipalName))
                                            $userRiskEventsDetailsTableContent = $userRiskEventsDetailsTableContent.Replace("riskEventLocCity", $($userRisk.location.city))
                                            $userRiskEventsDetailsTableContent = $userRiskEventsDetailsTableContent.Replace("riskEventLocCountry", $($userRisk.location.countryOrRegion))
                                            $userRiskEventsDetailsTableContent = $userRiskEventsDetailsTableContent.Replace("riskEventIpAddress", $($userRisk.ipAddress))

                                            $userRiskTableBody += $userRiskEventsDetailsTableContent
                                        }
                                    }
                                        # User Risk SignIn Events Results End
                                        $userRiskEventsTableHeaderEnd = '</thead></table>'

                                        $userRiskEventsTableDisplay = $userRiskEventsTableHeader + $userRiskTableBody + $userRiskEventsTableHeaderEnd
                                        $output3 = $userRiskEventsTableDisplay
                                }else {        
                                    $userRiskEventsCount = 0
                                    $output3 = "<h2>User sign-in risk events in last 30 days</h2><p>No user sign-in risk events found.</p>"
                                }
                            }
                            4 {# User Details
                                $userAADDetails = $null                                                                                                 
                                $userAADDetails = $jobResult.body
                                write-output "AADUser Details: $($jobResult.body)"
                                if ($userAADDetails.userPrincipalName) {   
                                    
                                    # Get Manager
                                    $mgrUrl = $null
                                    $userADManager = $null 

                                    $mgrUrl = "https://graph.microsoft.com/beta/users/$($userAADDetails.userPrincipalName)/manager"
                                    $userADManager = Invoke-GraphRequest -AccessToken $newGraphAccessToken -Uri $mgrUrl -Method GET -ErrorAction SilentlyContinue
    
                                    # User Search Results Table Header Row
                                    $userAADTableHeader = '<h2>User Details</h2><table class="table table-sm" id="returnedAADUserDetails"> 
                                    <thead>
                                        <tr>                                       
                                            <th>Account Enabled</th>    
                                            <th>User Type</th>
                                            <th>Display Name</th>                                            
                                            <th>userPrincipalName (UPN)</th>
                                            <th>email</th>
                                            <th>Department</th>                                            
                                            <th>Job Title</th>
                                            <th>Office Location</th>
                                            <th>samAccountName</th>
                                            <th>Manager</th>
                                            </tr>'   
                
                                    $userAADTableBody = @()

                                    $userType = $null 
                                    if ($userAADDetails.userPrincipalName.Contains("#EXT#")){
                                        $userType = "B2B"
                                    } else {
                                        if ($userAADDetails.OnPremisesSecurityIdentifier){
                                            $userType = "Hybrid"
                                        } else {
                                            $userType = "Cloud"
                                        }
                                    }
                                    Write-output "User: $($userAADDetails.DisplayName) UPN: $($userAADDetails.UserPrincipalName) is a $($userType) account"           
                                    
                                    $userAADDetailsTableContent = "<tr>                                         
                                    <td>searchUserAccountEnabled</td>
                                    <td>searchUserType</td>
                                    <td>searchUserDisplayName</td>
                                    <td>searchUserUPN</td>
                                    <td>searchUserEmail</td>
                                    <td>searchUserDepartment</td>
                                    <td>searchJobTitle</td>
                                    <td>searchOfficeLocation</td>
                                    <td>searchUserSamAccountName</td>
                                    <td>searchUserManager</td>
                                    </tr>"

                                    if ($userADManager.ContentObject.displayName){
                                        $userAADDetailsTableContent = $userAADDetailsTableContent.Replace("searchUserManager",$($userADManager.ContentObject.displayName))
                                    } else {
                                        $userAADDetailsTableContent = $userAADDetailsTableContent.Replace("searchUserManager","")
                                    }
                                    $userAADDetailsTableContent = $userAADDetailsTableContent.Replace("searchUserSamAccountName",$($userAADDetails.onPremisesSamAccountName))
                                    $userAADDetailsTableContent = $userAADDetailsTableContent.Replace("searchUserAccountEnabled",$($userAADDetails.accountEnabled))
                                    $userAADDetailsTableContent = $userAADDetailsTableContent.Replace("searchUserDisplayName",$($userAADDetails.displayName))
                                    $userAADDetailsTableContent = $userAADDetailsTableContent.Replace("searchUserUPN",$($userAADDetails.userPrincipalName))
                                    $userAADDetailsTableContent = $userAADDetailsTableContent.Replace("searchUserEmail",$($userAADDetails.mail))
                                    $userAADDetailsTableContent = $userAADDetailsTableContent.Replace("searchUserDepartment",$($userAADDetails.department))
                                    $userAADDetailsTableContent = $userAADDetailsTableContent.Replace("searchUserType",$($userType))
                                    $userAADDetailsTableContent = $userAADDetailsTableContent.Replace("searchJobTitle",$($userAADDetails.jobTitle))
                                    $userAADDetailsTableContent = $userAADDetailsTableContent.Replace("searchOfficeLocation",$($userAADDetails.officeLocation))
        
                                    $userAADTableBody += $userAADDetailsTableContent
                        
                                    # User Search Results End
                                    $userAADTableHeaderEnd = '</thead></table>'
                
                                    $userAADTableDisplay = $userAADTableHeader + $userAADTableBody + $userAADTableHeaderEnd
                                    $output4 = $userAADTableDisplay
                                }else{                                    
                                    $output4 = "<h2>User Details</h2><p>AAD User unable to be returned</p>"
                                }
                            }
                            5 {# User Device Details
                                $userDeviceDetails = $null                                                                                                 
                                $userDeviceDetails = $jobResult.body

                                write-output "&&&&&&&&&&&&&&&++++++++++&&&&&&&&&&&&&&&"
                                write-output "Devices $($userDeviceDetails)"
                                write-output "&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&"
                                write-output "Devices Details: $($jobResult.body)"

                                if ($userDeviceDetails.value.count -gt 0) {   
                                    $userDevicesCount = $userDeviceDetails.value.count
                                    $userDeviceTableBody = @()
                                    foreach ($device in $userDeviceDetails.value){
                                        write-output "Device OS: $($device.operatingSystem)"
                                        write-output "Device OSVer: $($device.operatingSystemVersion)"
                                        write-output "Device TrustType: $($device.trustType)"
                                        write-output "Device DisplayName: $($device.displayName)"
                                    
                                    # User Device Results Table Header Row
                                    $userDeviceTableHeader = '<h2>User Device(s) Details</h2><table class="table table-sm" id="returnedUserDevicesDetails"> 
                                    <thead>
                                        <tr>                                       
                                            <th>Device OS</th>    
                                            <th>Device OSVer</th>
                                            <th>Device Trust Type</th>                                            
                                            <th>Device Name</th>
                                            </tr>'                                                      
                                    
                                    Write-output "User: $($userAADDetails.DisplayName) UPN: $($userAADDetails.UserPrincipalName) is a $($userType) account"           
                                    
                                    $userDeviceDetailsTableContent = "<tr>                                         
                                    <td>" + $device.operatingSystem + "</td>
                                    <td>" + $device.operatingSystemVersion +"</td>
                                    <td>" + $device.trustType + "</td>
                                    <td>" + $device.displayName + "</td>
                                    </tr>"
                               
                                    $userDeviceTableBody += $userDeviceDetailsTableContent                        
                                } 
                                # User Search Results End
                                $userDeviceTableHeaderEnd = '</thead></table>'

                                $userDeviceTableDisplay = $userDeviceTableHeader + $userDeviceTableBody + $userDeviceTableHeaderEnd
                                $output5 = $userDeviceTableDisplay
                                
                                }else{                                    
                                    $output5 = "<h2>User Device Details</h2><p>No Devices Registered</p>"
                                    $userDevicesCount = 0
                                }
                            }
                        }
                    }
                }
            } catch {
                $output = $_.Exception.Message
                Write-output "Failed to perform request: $output"
                continue
            }
        }
    }
}

# Gather the output
$alloutput = @{}
$alloutput.add("id1",$output1)
$alloutput.add("id1Count", $userPwdEventsCount)
$alloutput.add("id2",$output2)
$alloutput.add("id2Count", $userSignInEventsCount)
$alloutput.add("id3",$output3)
$alloutput.add("id3Count", $userRiskEventsCount)
# User Details and Devices combined for output to same DIV
$userDetailsDevices = $output4 + $output5
$alloutput.add("id4",$userDetailsDevices)
$alloutput.add("id5Count",$userDevicesCount)

# Convert to JSON
$output = $alloutput | convertTo-json 
#$output

write-output $output
# Return the result
Out-File -Encoding Ascii -FilePath $res -inputObject $output
