# POST method: $req
$requestBody = Get-Content $req -Raw | ConvertFrom-Json
$uri = $requestBody.uri
$body = $requestBody.body
$method = $requestBody.method

write-output "URI: $($uri)"
write-output "body: $($body)"
write-output "method: $($method)"

# Enable Basic Parsing otherwise webrequests fail
& $(get-module PSMSGraph) {$PSDefaultParameterValues['Invoke-WebRequest:UseBasicParsing']=$true}

$tokensPath = 'D:\home\site\wwwroot\MSUser\token\'

if (test-path -Path $tokensPath) {   
    # Managed Service Identity EndPoint 
    $endpoint = $env:MSI_ENDPOINT
    $secret = $env:MSI_SECRET
    $vaultTokenURI = 'https://vault.azure.net&api-version=2017-09-01'

    # Vault URI's for Access and Refresh Tokens
    # NOTE: API Version for these calls is 2016-10-01
    $vaultSecretAccessTokenURI = 'https://yourVaultName.vault.azure.net/secrets/AccessToken?'
    $vaultSecretRefreshTokenURI = 'https://yourVaultName.vault.azure.net/secrets/RefreshToken?'

    # Create AuthN Header with our Function App Secret
    $header = @{'Secret' = $secret}

    # Get Key Vault Access Token
    $authenticationResult = Invoke-RestMethod -Method Get -Headers $header -Uri ($endpoint +'?resource=' +$vaultTokenURI)
    # Use Key Vault Access Token to create Request Header
    $requestHeader = @{ Authorization = "Bearer $($authenticationResult.access_token)" }

    # Call the Vault and Retrieve Creds
    # Refresh Token
    $rt = Invoke-RestMethod -Method GET -Uri "$($vaultSecretRefreshTokenURI)api-version=2016-10-01" -ContentType 'application/json' -Headers $requestHeader
    $refreshToken = $rt.value
    write-output "===Refresh Token==="
    write-output $refreshToken
    write-output "************************"

    # Access Token
    $at = Invoke-RestMethod -Method GET -Uri "$($vaultSecretAccessTokenURI)api-version=2016-10-01" -ContentType 'application/json' -Headers $requestHeader
    $accessToken = $at.value
    write-output "===Access Token==="
    write-output $accessToken
    write-output "************************"

    # Token artifacts
    $tokenReponseFile = 'myTokenResponse.json'
    $response = get-content -path "$($tokensPath)$($tokenReponseFile)" | ConvertFrom-Json

    $tokenReponseHeadersFile = 'myTokenResponseHeaders.json'
    $responseHeaders = get-content -path "$($tokensPath)$($tokenReponseHeadersFile)" | ConvertFrom-Json

    $graphAppFile = 'myGraphApp.json'
    $graphApp = get-content -path "$($tokensPath)$($graphAppFile)" | ConvertFrom-Json
    
    $graphAppCredPwd = ConvertTo-SecureString "yourAppSecret" -AsPlainText -Force
    $graphAppCreds = New-Object System.Management.Automation.PSCredential ("yourAppID", $graphAppCredPwd)

    $GraphApplication = [pscustomobject]@{PSTypeName = 'MSGraphAPI.Application' 
        Name = $graphApp.Name
        Description = $graphApp.Description 
        ClientCredential = $graphAppCreds 
        RedirectUri = $graphApp.RedirectUri
        Tenant = $graphApp.Tenant  
        GUID = $graphApp.GUID            
        }

    $tokenRequestDateFile = 'myTokenRequestDate.txt'
    $tokenRequestDate = get-content -path "$($tokensPath)$($tokenRequestDateFile)" 
    $tokenRDate = get-date($tokenRequestDate)

    $tokenLastRequestDateFile = 'myTokenLastRequestDate.txt'
    $tokenLastRequestDate = get-content -path "$($tokensPath)$($tokenLastRequestDateFile)" 
    $tokenLRDate = get-date($tokenLastRequestDate)
    
    # GET NEW TOKENS & Export for next run

    if ($response -and $responseHeaders -and $GraphApplication -and $tokenRDate -and $tokenLRDate -and $refreshToken -and $accessToken) {

        $graphAppAccessToken = ConvertTo-SecureString $accessToken -AsPlainText -Force
        $graphAppAccessTokenCreds = New-Object System.Management.Automation.PSCredential ("graphAppAT", $graphAppAccessToken)

        $graphAppRefreshToken = ConvertTo-SecureString $refreshToken -AsPlainText -Force
        $graphAppRefreshTokenCreds = New-Object System.Management.Automation.PSCredential ("graphAppRT", $graphAppRefreshToken)
                                
        $GraphAccessToken = New-GraphOauthAccessToken -AccessTokenCredential $graphAppAccessTokenCreds -RefreshTokenCredential $graphAppRefreshTokenCreds -RequestedDate $tokenRDate -LastRequestDate $tokenLRDate -Application $graphApplication -Response $response -ResponseHeaders $responseHeaders            
        
        if ($GraphAccessToken) {
            # Check to see if Token has expired. Refresh if it has and is Refreshable.
            if (($GraphAccessToken.IsExpired.Equals($True) -and $GraphAccessToken.IsRefreshable.Equals($True) ))  {
                write-output "Token has expired but is refreshable. Refreshing Tokens."
                Update-GraphOauthAccessToken -AccessToken $GraphAccessToken -Force 
                $tokenDebugFile = 'tokendebug.json'
                $GraphAccessToken | convertto-json | out-file "$($tokensPath)$($tokenDebugFile)"            
            }

            $timeNow = Get-date 
            if ($timeNow.AddMinutes(10) -gt $GraphAccessToken.Expires) {
                # Refresh token as it may expire before this execution completes
                write-output "Token will expire at $($GraphAccessToken.Expires) so refreshing so it doesn't expire before Function completes."
                Update-GraphOauthAccessToken -AccessToken $GraphAccessToken -Force 
                $tokenDebugFile = 'tokendebug.json'
                $GraphAccessToken | convertto-json | out-file "$($tokensPath)$($tokenDebugFile)" 
                write-output "Tokens refreshed and will now expire at $($GraphAccessToken.Expires)."           
            }
        }
        
        # Output info for next run if new token is valid
        if ($GraphAccessToken) {
            if (($GraphAccessToken.IsExpired.Equals($False) -and $GraphAccessToken.IsRefreshable.Equals($True) ))  {
                $newGraphAccessToken = $GraphAccessToken
                
                write-output "Tokens are valid. Exporting token info for next execution"
                
                $tokenResponse = $GraphAccessToken.Response | Select-Object -property * -ExcludeProperty access_token, refresh_token
                $tokenResponse | convertto-json | out-file "$($tokensPath)$($tokenReponseFile)"                                
                
                $GraphAccessToken.ResponseHeaders | convertto-json | out-file "$($tokensPath)$($tokenReponseHeadersFile)" 
                
                $GraphAccessToken.RequestedDate.DateTime | out-file "$($tokensPath)$($tokenRequestDateFile)"

                $GraphAccessToken.LastRequestDate.DateTime | out-file "$($tokensPath)$($tokenLastRequestDateFile)"

                # Update Access and Refresh Toekns in the Vault
                # New Token Values
                $bodyAT = @{value = $GraphAccessToken.GetAccessToken()} | convertTo-Json
                $bodyRT = @{value = $GraphAccessToken.GetRefreshToken()} | convertTo-Json

                # Update Vault with new tokens
                # NOTE: API Ver for this is 7.0
                write-output "AccessToken $($vaultSecretAccessTokenURI)api-version=7.0"
                $newAT = Invoke-RestMethod -Method Put -Uri "$($vaultSecretAccessTokenURI)api-version=7.0" -ContentType 'application/json' -Headers $requestHeader -body $bodyAT
                write-output "-------------------"
                write-output $newAT

                write-output "RefreshToken $($vaultSecretRefreshTokenURI)api-version=7.0"
                $newRT = Invoke-RestMethod -Method Put -Uri "$($vaultSecretRefreshTokenURI)api-version=7.0" -ContentType 'application/json' -Headers $requestHeader -body $bodyRT
                write-output "+++++++++++++++++++"
                write-output $newRT

            } else {
                write-output "oAuth Token is Expired or cannot be Refreshed. Update externally and upload to Az Function"
                $output = "oAuth Token is Expired or cannot be Refreshed. Update externally and upload to Az Function"
            }
        } else {
            write-output "New oAuth Token attempt failed. Token not valid"
            $output = "oAuth Token is Expired or cannot be Refreshed. Update externally and upload to Az Function"
        }   
            
    } else {
        write-output "Some oAuth Refresh information not found"
        $output = "Some oAuth Refresh information not found"            
    }

} else {
    write-output "oAuth Refresh information not found"
    $output = "oAuth Refresh information not found" 
}

# Checkout the Request and execute it

if ($uri -and $method){
    if ($GraphAccessToken.IsExpired.Equals($False)) {

        if (!$body){
            try{
                #$requestResult = Invoke-GraphRequest -AccessToken $newGraphAccessToken -Uri $uri -Method $method
                
                $result = Invoke-GraphRequest -uri $uri -AccessToken $GraphAccessToken -method Get 
                if ($result.contentObject.value){
                    $userSearchResults = $result.contentObject.value

                    # User Search Results Table Header Row
                    $userSearchTableHeader = '<h2>User Search Results</h2><table class="table table-sm" id="userSearchTable"> 
                    <thead>
                        <tr>
                        <th></th>
                            <th>Display Name</th>
                            <th>userPrincipalName (UPN)</th>
                            <th>email</th>
                            <th>Department</th>
                            <th>User Type</th>
                            </tr>'   

                    # User Search Table Content
                    if ($userSearchResults.Count -gt 0){
                        $userSearchTableBody = @()
                        foreach ($user in $userSearchResults){
                    #       if ($user.userPrincipalName.Contains("qantas.com.au")){break}
                            $userType = $null 
                            if ($user.userPrincipalName.Contains("#EXT#")){
                                $userType = "B2B"
                            } else {
                                if ($user.OnPremisesSecurityIdentifier){
                                    $userType = "Hybrid"
                                } else {
                                    $userType = "Cloud"
                                }
                            }
                            Write-output "User: $($user.DisplayName) UPN: $($user.UserPrincipalName) is a $($userType) account"           
                            
                            $userSearchDetailsTableContent = "<tr>
                            <td><button type=`"button`" class=`"btn btn-primary`" onclick=`"getUserDetails('userSearchTable')`">lookup</button></td>
                            <td>searchUserDisplayName</td>
                            <td>searchUserUPN</td>
                            <td>searchUserEmail</td>
                            <td>searchUserDepartment</td>
                            <td>searchUserType</td>
                            </tr>"

                            $userSearchDetailsTableContent = $userSearchDetailsTableContent.Replace("searchUserDisplayName",$($user.displayName))
                            $userSearchDetailsTableContent = $userSearchDetailsTableContent.Replace("searchUserUPN",$($user.userPrincipalName))
                            $userSearchDetailsTableContent = $userSearchDetailsTableContent.Replace("searchUserEmail",$($user.mail))
                            $userSearchDetailsTableContent = $userSearchDetailsTableContent.Replace("searchUserDepartment",$($user.department))
                            $userSearchDetailsTableContent = $userSearchDetailsTableContent.Replace("searchUserType",$($userType))

                            $userSearchTableBody += $userSearchDetailsTableContent

                        }
                    }     

                    # User Search Results End
                    $userSearchTableHeaderEnd = '</thead></table>'

                    $userSearchTableDisplay = $userSearchTableHeader + $userSearchTableBody + $userSearchTableHeaderEnd
                    $output = $userSearchTableDisplay
                }else{
                    $userSearchResults = $null
                    $output = "<p>No users found for your search criteria</p>"
                }
               
            } catch {
                $output = $_.Exception.Message
                Write-output "Failed to perform request: $output"
                continue
            }                            
        } else {            
            try{
                $requestResult = Invoke-GraphRequest -AccessToken $newGraphAccessToken -Uri $uri -Method $method -body $body
                $output = $requestResult.ContentObject.value | ConvertTo-Json
            } catch {
                $output = $_.Exception.Message
                Write-output "Failed to perform request: $output"
                continue
            }
        }

    }
}

# Return the result
Out-File -Encoding Ascii -FilePath $res -inputObject $output
