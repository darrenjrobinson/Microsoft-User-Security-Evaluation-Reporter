# POST method: $req
$requestBody = Get-Content $req -Raw | ConvertFrom-Json
write-output $requestBody
$user = $requestBody.user
write-output "User: $($user)"

if ($user){
    switch ($user){
        "1" {
            # Not Pwned
            $output = '<div class="progress">
            <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="100"
                aria-valuemin="0" aria-valuemax="100" style="width:100%">
                Not Pwned - Awesome
            </div>
        </div>'

        }
        "2" {
            # Pwned
            $output = '<div class="progress">
            <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="100"
                aria-valuemin="0" aria-valuemax="100" style="width:100%">
                AD Password Pwned!! - Advise User to change it
            </div>
        </div>'

        }
    }
} else {
    $output = "<h2>User not found in AD</h2>"
}

write-output $output
Out-File -Encoding Ascii -FilePath $res -inputObject $output
