# POST method: $req
$requestBody = Get-Content $req -Raw | ConvertFrom-Json

# Managed Service Identity EndPoint 
$endpoint = $env:MSI_ENDPOINT
$secret = $env:MSI_SECRET
$vaultTokenURI = 'https://vault.azure.net&api-version=2017-09-01'

# Vault URI's for Access and Refresh Tokens
# NOTE: API Version for these calls is 2016-10-01
$vaultSecretADHostURI = 'https://yourVaultName.vault.azure.net/secrets/ADDCHost?'
$vaultSecretADUserURI = 'https://yourVaultName.vault.azure.net/secrets/ADDCUser?'
$vaultSecretADPasswordURI = 'https://yourVaultName.vault.azure.net/secrets/ADDCPassword?'

# Create AuthN Header with our Function App Secret
$header = @{'Secret' = $secret}

# Get Key Vault Access Token
$authenticationResult = Invoke-RestMethod -Method Get -Headers $header -Uri ($endpoint +'?resource=' +$vaultTokenURI)
# Use Key Vault Access Token to create Request Header
$requestHeader = @{ Authorization = "Bearer $($authenticationResult.access_token)" }

# Call the Vault and Retrieve Creds
# Active Directory Host, Username and Password
$adHost = Invoke-RestMethod -Method GET -Uri "$($vaultSecretADHostURI)api-version=2016-10-01" -ContentType 'application/json' -Headers $requestHeader
$username = Invoke-RestMethod -Method GET -Uri "$($vaultSecretADUserURI)api-version=2016-10-01" -ContentType 'application/json' -Headers $requestHeader
$adPwd = Invoke-RestMethod -Method GET -Uri "$($vaultSecretADPasswordURI)api-version=2016-10-01" -ContentType 'application/json' -Headers $requestHeader

Write-Output "hostName: $($adHost.value)"
Write-Output "username: $($username.value)"
Write-Output "adPwd: $($adPwd.value)"

$userUPN = $requestBody.user
$hostName = $adHost.value
$winrmPort = "5986"

# PS Creds 
# Create PS Creds
# Generate Creds. Get the credentials of the machine
$pw = $adPwd.value | convertto-securestring -AsPlainText -Force 
$mycreds = New-Object System.Management.Automation.PSCredential $username.value,$pw

#Open-Store -Path "C:\passwordfilter\store"
# Connection Options
$sessionOptions = New-PSSessionOption -SkipCACheck
# Setup scriptblock 
$scriptblock = {param($userUPN)
    Import-Module LithnetPasswordProtection    
    Test‐IsADUserPasswordCompromised -upn $userUPN 
    #$PSVersionTable | convertTo-Json
    } 
 
# Connect to Domain Server and execure the query 
$output = Invoke-Command $scriptblock -computer $hostName -Port $winrmPort -Credential $mycreds -SessionOption $sessionOptions -UseSSL -argumentlist $userUPN  
$output

Out-File -Encoding Ascii -FilePath $res -inputObject $output
