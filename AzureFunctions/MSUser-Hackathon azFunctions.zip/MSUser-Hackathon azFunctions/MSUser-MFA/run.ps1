# POST method: $req
$requestBody = Get-Content $req -Raw | ConvertFrom-Json
$query = $requestBody.query
write-output "Request: $($requestBody)"
write-output "Query: $($query)"

# Managed Service Identity EndPoint 
$endpoint = $env:MSI_ENDPOINT
$secret = $env:MSI_SECRET
$vaultTokenURI = 'https://vault.azure.net&api-version=2017-09-01'

# Vault URI's for Azure Table Storage Access
# NOTE: API Version for these calls is 2017-04-17
$vaultSecretstorageAccountkeyURI = 'https://yourVaultName.vault.azure.net/secrets/storageAccountkey?'
$vaultSecretstorageAccountNameURI = 'https://yourVaultName.vault.azure.net/secrets/storageAccountName?'

# Create AuthN Header with our Function App Secret
$header = @{'Secret' = $secret}

# Get Key Vault Access Token
$authenticationResult = Invoke-RestMethod -Method Get -Headers $header -Uri ($endpoint + '?resource=' + $vaultTokenURI)
# Use Key Vault Access Token to create Request Header
$requestHeader = @{ Authorization = "Bearer $($authenticationResult.access_token)" }

# Call the Vault and Retrieve Creds
# Storage Account Key
$sKey = Invoke-RestMethod -Method GET -Uri "$($vaultSecretstorageAccountkeyURI)api-version=2016-10-01" -ContentType 'application/json' -Headers $requestHeader
$storageAccountKey = $sKey.value
write-output "===Storage Key==="
write-output $storageAccountKey
write-output "************************"

# Storage Account Name
$sName = Invoke-RestMethod -Method GET -Uri "$($vaultSecretstorageAccountNameURI)api-version=2016-10-01" -ContentType 'application/json' -Headers $requestHeader
$storageAccountName = $sName.value
write-output "===Storage Name==="
write-output $storageAccountName
write-output "************************"

# Checkout the Request and execute it
if ($query -and ($storageAccountName -or $storageAccountKey)) {
       
    $version = "2017-04-17"
    # Resource = Table Name 
    $resource = "MFA"    
    
    $queryURL = "https://$($storageAccountName).table.core.windows.net/$($resource)?`$filter=($($query))"
    
    $GMTTime = (Get-Date).ToUniversalTime().toString('R')
    $stringToSign = "$GMTTime`n/$storageAccountName/$resource"
    $hmacsha = New-Object System.Security.Cryptography.HMACSHA256
    $hmacsha.key = [Convert]::FromBase64String($storageAccountkey)
    $signature = $hmacsha.ComputeHash([Text.Encoding]::UTF8.GetBytes($stringToSign))
    $signature = [Convert]::ToBase64String($signature)
    $headers = @{
        'x-ms-date'    = $GMTTime
        Authorization  = "SharedKeyLite " + $storageAccountName + ":" + $signature
        "x-ms-version" = $version
        Accept         = "application/json;odata=fullmetadata"
    }
    
    try {       
        write-output "Query: $queryURL"
        $MFAitem = Invoke-RestMethod -Method GET -Uri $queryURL -Headers $headers -ContentType application/json
        #$MFAitem.value
        write-output $MFAitem.value.MFAMethod
        write-output $MFAitem.value.MFAApp
        write-output $MFAitem.value.MFAAppDeviceName
        #$output = $MFAitem.value | ConvertTo-Json
       
        if ($MFAitem.value) {
            switch ($MFAitem.value.MFAMethod) {
                "PhoneAppNotification" {$output1 = '<div class="progress"><div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="100"aria-valuemin="0" aria-valuemax="100" style="width:100%">Primary Method is Authenticator App</div></div>'}
                "OneWaySMS" {$output1 = '<div class="progress"><div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="66"aria-valuemin="0" aria-valuemax="100" style="width:66%">Primary Method is SMS Text</div></div>'}
                "TwoWayVoiceMobile" {$output1 = '<div class="progress"><div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="66"aria-valuemin="0" aria-valuemax="100" style="width:66%">Primary Method is Phone Call</div></div>'}
                "default" {$output1 = '<div class="progress"><div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="100"aria-valuemin="0" aria-valuemax="100" style="width:100%">NO MFA</div></div>'}
            }
        
            $output1
        
            $MFAMethodsTable = '<h2>Users MFA Methods</h2><table class="table table-sm" id="userMFADetailsTable"> 
                    <thead>
                        <tr>
                            <th>Primary MFA Method</th>            
                            <th>MFA Application</th>
                            <th>MFA App Device Name</th>
                            <th>MFA Email</th>
                            <th>MFA Phone</th>
                            <th>MFA Status</th>
                        </tr>
						<tr>
							<td>' + $MFAitem.value.MFAMethod + '</td>
							<td>' + $MFAitem.value.MFAApp + '</td>
							<td>' + $MFAitem.value.MFAAppDeviceName + '</td>
                            <td>' + $MFAitem.value.MFAEmail + '</td>
                            <td>' + $MFAitem.value.MFAPhone + '</td>
							<td>' + $MFAitem.value.MFAStatus + '</td>
						</tr>
                    </thead></table>' 
                    
            $output2 = $MFAMethodsTable             
        }
        else {
            $output1 = '<div class="progress"><div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="100"aria-valuemin="0" aria-valuemax="100" style="width:100%">NO MFA. Enforce MFA Enrollment.</div></div>'
        }

        # Gather the output
        $allMFAoutput = @{}
        $allMFAoutput.add("id1",$output1)
        $allMFAoutput.add("id2",$output2)
        # Convert to JSON
        $output = $allMFAoutput | convertTo-json 
    }
    catch {
        $output = $_.Exception.Message
        Write-output "Failed to perform request: $output"
        continue
    }    
}

# Return the result
Out-File -Encoding Ascii -FilePath $res -inputObject $output
